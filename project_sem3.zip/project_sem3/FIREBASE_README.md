# Firebase Integration Walkthrough

I have successfully integrated Firebase into your Flutter project. Here is how to verify and use the new features.

## Prerequisites
Before running the app, you **MUST** configure Firebase for your project:

1.  **Create a Firebase Project**: Go to [Firebase Console](https://console.firebase.google.com/).
2.  **Add Android App**:
    -   Package Name: `com.example.project_sem3`
    -   Download `google-services.json` and place it in `android/app/google-services.json`.
3.  **Enable Authentication**:
    -   Go to **Build > Authentication**.
    -   Enable **Email/Password** provider.
4.  **Enable Firestore**:
    -   Go to **Build > Firestore Database**.
    -   Create a database (Start in Test Mode for development).

## Features Implemented

### 1. Login Page
-   **Email/Password Login**: Enter a valid email and password.
-   **Registration**: Click "Don't have an account? Register" to create a new user.
-   **Logic**: Only authorized users can access the Home Page.

### 2. Clock In Flow
-   **Navigate**: Tap "CLOCK IN" on the Dashboard.
-   **Camera**: Tap the "Camera" icon to take a selfie.
-   **Flow**: Proceed through "Next" -> "GPS" -> "Clock In".
-   **Storage**: The record (Image Path, Time, Location) is saved to Firestore.

### 3. Clock Out Flow
-   **Navigate**: Tap "Clock Out" menu item on the Dashboard.
-   **Camera**: Tap the "Camera" icon to take a photo.
-   **Flow**: Proceed through "GPS Detection" -> "Clock Out".
-   **Storage**: The record is saved to Firestore.

### 4. My Record Page
-   **Navigate**: Tap "My Record" on the bottom navigation bar.
-   **Display**: Shows a list of all your Clock In and Clock Out activities, sorted by time.

## Verification Steps
1.  Run the app: `flutter run`.
2.  Register a new account on the Login Page.
3.  You will be redirected to the Dashboard.
4.  Tap "CLOCK IN", take a photo, and submit.
5.  Go to "My Record" tab and verify the entry appears.
6.  Go back Home, tap "Clock Out", take a photo, and submit.
7.  Check "My Record" again to see the Clock Out entry.

## Notes
-   **Images**: Images are currently stored using their **local path** for simplicity. They will only be visible on the device where they were taken. For cloud visibility, you would need to integrate **Firebase Storage**.
-   **GPS**: The location is currently hardcoded or simulated as per the existing UI design ("Kolej kediaman A11").
