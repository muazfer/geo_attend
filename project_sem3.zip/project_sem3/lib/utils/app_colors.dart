import 'package:flutter/material.dart';

class AppColors {
  static const Color royalBlue = Color(0xFF2B55CC);
  static const Color limeGreen = Color(0xFF76FF03);
  static const Color skyBlue = Color(0xFF40C4FF);
  // For GPS/Next buttons
  static const Color salmonRed = Color(0xFFFF8A80);
  // For Clock Out button
  static const Color successGreen = Color(0xFF00C853);
  static const Color alertRed = Color(0xFFD50000);
  static const Color warningPinkBg = Color(0xFFFFEBEE); // For Warning Box
  static const Color warningPinkBorder = Color(0xFFFFCDD2);
  static const Color greyBg = Color(0xFFF5F5F5);
  static const Color navyDeep = Color(0xFF241C96);
// Dark buttons
}
