import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class ClockOutAlertPopup extends StatelessWidget {
  const ClockOutAlertPopup({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.7),
      body: Center(
        child: Container(
          width: 300,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(5)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Alert !",
                  style: TextStyle(
                      color: AppColors.alertRed,
                      fontSize: 24,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              const Text("Please Insert the picture!!!",
                  style: TextStyle(fontSize: 18)),
              const SizedBox(height: 20),
              Align(
                alignment: Alignment.bottomRight,
                child: TextButton(
                  onPressed: () {
                    // YES Button -> Goes back to Previous Page (Clock Out 2)
                    Navigator.pop(context);
                  },
                  child: const Text("Yes",
                      style: TextStyle(
                          color: Colors.teal,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
