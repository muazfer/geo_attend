import 'package:flutter/material.dart';
import 'dart:io';
import '../utils/app_colors.dart';

class CameraFlowLayout extends StatelessWidget {
  final String title;
  final bool hasPhoto;
  final String placeholderText;
  final String placeStatus;
  final Color placeColor;
  final String faceStatus;
  final Color faceColor;
  final String? timeStatus;
  final Color? timeColor;
  final String buttonText;
  final VoidCallback onButtonPressed;
  final VoidCallback onCameraTap;
  final File? localImage;

  const CameraFlowLayout(
      {super.key, required this.title,
        required this.hasPhoto,
        required this.placeholderText,
        required this.placeStatus,
        required this.placeColor,
        required this.faceStatus,
        required this.faceColor,
        this.timeStatus,
        this.timeColor,
        required this.buttonText,
        required this.onButtonPressed,
        required this.onCameraTap,
        this.localImage});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.royalBlue,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const SizedBox(height: 20),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                    color: AppColors.greyBg,
                    borderRadius:
                    BorderRadius.vertical(top: Radius.circular(20))),
                child: Column(
                  children: [
                    Padding(
                        padding: const EdgeInsets.all(20),
                        child: Text(title,
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold))),
                    GestureDetector(
                      onTap: onCameraTap,
                      child: Container(
                        margin: const EdgeInsets.all(20),
                        height: 300,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: Colors.grey[300],
                            image: (hasPhoto && localImage != null)
                                ? DecorationImage(
                                image: FileImage(localImage!),
                                fit: BoxFit.cover)
                                : (hasPhoto 
                                  ? const DecorationImage(
                                      image: NetworkImage("https://via.placeholder.com/300"),
                                      fit: BoxFit.cover)
                                  : null)),
                        child: !hasPhoto
                            ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.camera_alt,
                                  size: 50, color: Colors.black54),
                              Text(placeholderText,
                                  style: const TextStyle(
                                      color: Colors.black54))
                            ])
                            : null,
                      ),
                    ),
                    const Spacer(),
                    Padding(
                        padding: const EdgeInsets.all(20),
                        child: SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.skyBlue),
                                onPressed: onButtonPressed,
                                child: Text(buttonText,
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold))))),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
