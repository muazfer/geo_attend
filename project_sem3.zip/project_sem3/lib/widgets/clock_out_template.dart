import 'dart:io';
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class ClockOutTemplate extends StatelessWidget {
  final String btnText;
  final Color btnColor;
  final String placeholderText;
  final String placeStatus;
  final String faceStatus;
  final bool hasPhoto;
  final String? timeText;
  final VoidCallback onBtnPressed;
  final VoidCallback onCameraTap;
  final File? localImage;

  const ClockOutTemplate({
    super.key,
    required this.btnText,
    required this.btnColor,
    required this.placeholderText,
    required this.placeStatus,
    required this.faceStatus,
    required this.hasPhoto,
    this.timeText,
    required this.onBtnPressed,
    required this.onCameraTap,
    this.localImage,
  });
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black54,
      appBar: AppBar(
        title: const Text("Clock Out", style: TextStyle(color: Colors.white)),
        backgroundColor: AppColors.royalBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        centerTitle: true,
      ),
      body: Center(
        child: Container(
          margin: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 20),
              // Use current user name if available?
              const Text("Hello, Cleaner", // Simplified
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: onCameraTap,
                child: Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    image: (hasPhoto && localImage != null)
                        ? DecorationImage(
                        image: FileImage(localImage!),
                        fit: BoxFit.cover)
                        : (hasPhoto 
                          ? const DecorationImage(
                              image: NetworkImage("https://via.placeholder.com/300"),
                              fit: BoxFit.cover)
                          : null),
                  ),
                  child: !hasPhoto
                      ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.camera_alt,
                          size: 50, color: Colors.black54),
                      Text(placeholderText,
                          style: const TextStyle(color: Colors.black54),
                          textAlign: TextAlign.center),
                    ],
                  )
                      : null,
                ),
              ),
              const SizedBox(height: 20),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey.withOpacity(0.2), blurRadius: 5)
                    ]),
                child: Column(
                  children: [
                    _statusRow("Place", placeStatus, true),
                    const Divider(),
                    if (timeText != null) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Time clock out",
                              style: TextStyle(color: Colors.black)),
                          Text(timeText!,
                              style: const TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const Divider(),
                    ],
                    _statusRow("Face", faceStatus, true),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: btnColor,
                    shape: const RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.vertical(bottom: Radius.circular(20))),
                  ),
                  onPressed: onBtnPressed,
                  child: Text(btnText,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusRow(String label, String value, bool isGreen) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: Colors.black)),
        Text(value,
            style: TextStyle(
                color: isGreen ? AppColors.successGreen : Colors.black,
                fontWeight: FontWeight.bold)),
      ],
    );
  }
}
