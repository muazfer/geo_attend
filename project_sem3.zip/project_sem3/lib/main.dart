import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/auth/main_selection_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyCleanAttendApp());
}

class MyCleanAttendApp extends StatelessWidget {
  const MyCleanAttendApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MyCleanAttend UTHM',
      theme: ThemeData(
        primaryColor: const Color(0xFF5356FF),
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Roboto',
      ),
      home: const MainSelectionPage(),
    );
  }
}