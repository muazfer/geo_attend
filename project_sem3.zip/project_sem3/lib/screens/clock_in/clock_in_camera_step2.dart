import 'package:flutter/material.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import '../../widgets/camera_flow_layout.dart';
import 'standard_gps_detection_page.dart';

class ClockInCameraStep2 extends StatelessWidget {
  final File? imageFile;
  const ClockInCameraStep2({super.key, this.imageFile});
  @override
  Widget build(BuildContext context) {
    return CameraFlowLayout(
      title: "Hello, Cleaner",
      hasPhoto: false,
      placeholderText: "Press here to take picture place",
      placeStatus: "No available",
      placeColor: Colors.grey,
      faceStatus: "Recognise",
      faceColor: AppColors.successGreen,
      timeStatus: "07:58 AM",
      timeColor: AppColors.successGreen,
      buttonText: "Next",
      onButtonPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => StandardGPSDetectionPage(imageFile: imageFile))),
      onCameraTap: () {},
    );
  }
}
