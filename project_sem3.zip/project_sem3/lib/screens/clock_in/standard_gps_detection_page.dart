import 'package:flutter/material.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import 'clock_in_welcome_page.dart';

class StandardGPSDetectionPage extends StatelessWidget {
  final File? imageFile;
  const StandardGPSDetectionPage({super.key, this.imageFile});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("GPS", style: TextStyle(color: Colors.white)),
          backgroundColor: AppColors.royalBlue,
          iconTheme: const IconThemeData(color: Colors.white)),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [AppColors.royalBlue, Colors.blueAccent])),
            child: const Column(children: [
              Icon(Icons.location_on, size: 50, color: Colors.white),
              SizedBox(height: 10),
              Text("Please enable GPS to verify your workspace.",
                  style: TextStyle(color: Colors.white))
            ]),
          ),
          Expanded(
              child: Center(
                  child: GestureDetector(
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => ClockInWelcomePage(imageFile: imageFile))),
                      child: Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                              color: AppColors.alertRed.withOpacity(0.3),
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: AppColors.alertRed, width: 2)),
                          child: const Center(
                              child: Icon(Icons.location_on,
                                  color: AppColors.alertRed, size: 40)))))),
        ],
      ),
    );
  }
}
