import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import 'clock_in_success_page_new.dart';

class ClockInWelcomePage extends StatefulWidget {
  final File? imageFile;
  const ClockInWelcomePage({super.key, this.imageFile});

  @override
  State<ClockInWelcomePage> createState() => _ClockInWelcomePageState();
}

class _ClockInWelcomePageState extends State<ClockInWelcomePage> {
  bool _isLoading = false;

  Future<void> _clockIn() async {
    setState(() => _isLoading = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        String? base64Image;
        if (widget.imageFile != null) {
          final bytes = await widget.imageFile!.readAsBytes();
          base64Image = base64Encode(bytes);
        }

        await FirebaseFirestore.instance.collection('attendance').add({
          'userId': user.uid,
          'type': 'Clock In',
          'timestamp': FieldValue.serverTimestamp(),
          'location': 'Kolej kediaman A11',
          'imagePath': base64Image ?? '', 
          'dateStr': DateFormat('yyyy-MM-dd').format(DateTime.now()),
          'timeStr': DateFormat('HH:mm a').format(DateTime.now()),
          'email': user.email ?? 'No Email',
          'userName': user.displayName ?? 'Unknown User',
        });
      }
      if (mounted) {
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const ClockInSuccessPageNew()));
      }
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      if(mounted) setState(()=>_isLoading=false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
          title: const Text("Clock In", style: TextStyle(color: Colors.white)),
          backgroundColor: AppColors.royalBlue,
          iconTheme: const IconThemeData(color: Colors.white)),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Expanded(
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 10),
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const Text("WELCOME TO UTHM",
                      style:
                      TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  widget.imageFile != null
                  ? Container(
                      height: 200,
                      width: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(image: FileImage(widget.imageFile!), fit: BoxFit.cover)
                      ),
                    )
                  : const Icon(Icons.apartment, size: 100, color: Colors.grey),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: _isLoading ? const Center(child: CircularProgressIndicator()) : ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.limeGreen),
                            onPressed: _clockIn,
                            child: const Text("Clock In",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold)))),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
