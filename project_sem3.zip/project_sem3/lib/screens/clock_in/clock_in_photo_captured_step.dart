import 'package:flutter/material.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import '../../widgets/camera_flow_layout.dart';
import 'clock_in_camera_step2.dart';

class ClockInPhotoCapturedStep extends StatelessWidget {
  final File? imageFile;
  const ClockInPhotoCapturedStep({super.key, this.imageFile});
  @override
  Widget build(BuildContext context) {
    return CameraFlowLayout(
      title: "Hello, Cleaner",
      hasPhoto: true,
      localImage: imageFile,
      placeholderText: "",
      placeStatus: "No available",
      placeColor: Colors.grey,
      faceStatus: "Recognise",
      faceColor: AppColors.successGreen,
      timeStatus: "07:58 AM",
      timeColor: AppColors.successGreen,
      buttonText: "Next",
      onButtonPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => ClockInCameraStep2(imageFile: imageFile))),
      onCameraTap: () {},
    );
  }
}
