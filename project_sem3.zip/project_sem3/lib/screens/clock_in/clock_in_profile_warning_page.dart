import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import 'clock_in_success_page_new.dart';

class ClockInProfileWarningPage extends StatelessWidget {
  const ClockInProfileWarningPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.greyBg,
      appBar: AppBar(
        title: const Text("Clock In", style: TextStyle(color: Colors.white)),
        backgroundColor: AppColors.royalBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(15)),
              child: Column(
                children: [
                  const CircleAvatar(
                      radius: 40,
                      backgroundImage:
                      NetworkImage("https://via.placeholder.com/150")),
                  const SizedBox(height: 10),
                  const Text("Ikhmal Bin Sarafuddin",
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Text("Cleaner", style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 5),
                  const Text("012-3456789",
                      style: TextStyle(color: Colors.blue)),
                  const SizedBox(height: 20),
                  const Divider(),
                  const SizedBox(height: 10),
                  _buildSummaryRow("Place", "Kolej kediaman A11"),
                  _buildSummaryRow("Time in", "08:00 AM"),
                  _buildSummaryRow("Face", "Recognise"),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: AppColors.warningPinkBg,
                      border: Border.all(color: AppColors.warningPinkBorder),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      "Please inform to management about your attendance camera cannot used before clock out.",
                      style: TextStyle(color: Colors.redAccent, fontSize: 13),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.limeGreen,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () {
                    // CLOCK IN Button -> Opens Page 10 (Success)
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                            const ClockInSuccessPageNew()));
                  },
                  child: const Text("CLOCK IN",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Text(value,
              style: const TextStyle(
                  fontWeight: FontWeight.bold, color: AppColors.successGreen)),
        ],
      ),
    );
  }
}
