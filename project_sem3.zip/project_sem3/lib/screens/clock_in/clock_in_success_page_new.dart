import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';

class ClockInSuccessPageNew extends StatelessWidget {
  const ClockInSuccessPageNew({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Clock In", style: TextStyle(color: Colors.white)),
        backgroundColor: AppColors.royalBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 50),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 30),
            child: Text(
              "SUCCESSFULLY YOUR ATTENDANCE HAS BEEN RECORDED !!!",
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: AppColors.successGreen,
                  fontSize: 24,
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 30),
          Container(
            height: 150,
            width: 150,
            decoration: const BoxDecoration(
                color: AppColors.successGreen, shape: BoxShape.circle),
            child: const Icon(Icons.check, color: Colors.white, size: 80),
          ),
          const SizedBox(height: 40),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 10)
                ]),
            child: const Column(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text("Place"),
                  Text("Valid",
                      style: TextStyle(
                          color: AppColors.successGreen,
                          fontWeight: FontWeight.bold))
                ]),
                Divider(),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text("Face"),
                  Text("Valid",
                      style: TextStyle(
                          color: AppColors.successGreen,
                          fontWeight: FontWeight.bold))
                ]),
                Divider(),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text("Your working hours:"),
                  Text("08:00 AM - 05:00 PM",
                      style: TextStyle(
                          color: AppColors.royalBlue,
                          fontWeight: FontWeight.bold))
                ]),
              ],
            ),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.limeGreen,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  // SUBMIT Button -> Return to Home
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
                child: const Text("Submit",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18)),
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
