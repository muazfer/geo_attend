import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import 'clock_in_profile_warning_page.dart';

class ClockInCameraErrorPage extends StatelessWidget {
  const ClockInCameraErrorPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("MyCleanAttend UTHM",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: AppColors.royalBlue,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Spacer(),
          Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.camera_alt, size: 100, color: Colors.grey),
              Positioned(
                  top: 0,
                  right: 0,
                  child: Icon(Icons.block, size: 40, color: Colors.red[300])),
            ],
          ),
          const SizedBox(height: 10),
          const Icon(Icons.sentiment_dissatisfied,
              size: 40, color: Colors.grey),
          const SizedBox(height: 20),
          const Text("Cannot Access Camera",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 40),
            child: Text(
                "We cannot access your camera.Please check permissions or try again.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey)),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.limeGreen,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                onPressed: () {
                  // CLOCK IN Button -> Opens Page 9 (Profile/Warning)
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const ClockInProfileWarningPage()));
                },
                child: const Text("CLOCK IN",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Text("Clock in directly",
              style: TextStyle(
                  color: Colors.blue, decoration: TextDecoration.underline)),
          const SizedBox(height: 30),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        // REMOVED QR CODE BUTTON ITEM FROM ERROR PAGE TOO
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.inbox), label: "Inbox"),
          BottomNavigationBarItem(icon: Icon(Icons.receipt), label: "Record"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
        currentIndex: 0,
        selectedItemColor: AppColors.royalBlue,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          if (index == 0) Navigator.popUntil(context, (route) => route.isFirst);
        },
      ),
    );
  }
}
