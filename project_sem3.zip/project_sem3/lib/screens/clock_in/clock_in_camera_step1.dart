import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../widgets/camera_flow_layout.dart';
import '../../widgets/clock_out_alert_popup.dart';
import 'clock_in_photo_captured_step.dart';
import 'standard_gps_detection_page.dart';

class ClockInCameraStep1 extends StatelessWidget {
  const ClockInCameraStep1({super.key});
  @override
  Widget build(BuildContext context) {
    return CameraFlowLayout(
      title: "Hello, Cleaner",
      hasPhoto: false,
      placeholderText: "Press here to take picture face",
      placeStatus: "No available",
      placeColor: Colors.grey,
      faceStatus: "No face",
      faceColor: Colors.grey,
      buttonText: "GPS DETECTION",
      onButtonPressed: () {
        showDialog(
            context: context, builder: (_) => const ClockOutAlertPopup());
      },
      onCameraTap: () async {
        final ImagePicker picker = ImagePicker();
        final XFile? image = await picker.pickImage(
          source: ImageSource.camera,
          imageQuality: 50,
          maxWidth: 600,
        );
        if (image != null && context.mounted) {
           Navigator.push(context,
            MaterialPageRoute(builder: (_) => StandardGPSDetectionPage(imageFile: File(image.path))));
        }
      },
    );
  }
}
