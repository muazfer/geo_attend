import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("Calendar", style: TextStyle(color: Colors.white)),
          backgroundColor: AppColors.royalBlue,
          iconTheme: const IconThemeData(color: Colors.white)),
      body: Column(
        children: [
          Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              color: const Color(0xFF1A237E),
              child: const Text("Scheduled Attendance",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold))),
          Expanded(
              child: ListView.builder(
                  itemCount: 3,
                  itemBuilder: (context, index) =>
                      _buildMonthSection("0${index + 1}/2025"))),
        ],
      ),
    );
  }

  Widget _buildMonthSection(String monthTitle) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text(monthTitle,
              style:
              const TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
      GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7),
          itemCount: 30,
          itemBuilder: (context, dayIndex) => Container(
              margin: const EdgeInsets.all(2),
              decoration:
              BoxDecoration(border: Border.all(color: Colors.grey[300]!)),
              child: Center(
                  child: Icon(
                      dayIndex % 6 != 0 ? Icons.check_circle : Icons.cancel,
                      color: dayIndex % 6 != 0
                          ? AppColors.successGreen
                          : Colors.red,
                      size: 16)))),
      const Divider()
    ]);
  }
}
