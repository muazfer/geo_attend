import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../utils/app_colors.dart';
import 'leave_application_page.dart';

class LeavePage extends StatelessWidget {
  const LeavePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: AppColors.royalBlue,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context)),
          title: const Text("Leave",
              style:
              TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text("Leave Balance",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(color: Colors.grey.shade300, blurRadius: 10)
                    ]),
                child: const Column(children: [
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [Text("Annual: 8/8"), Text("Medical: 12/14")]),
                  SizedBox(height: 10),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Emergency: 12/12"),
                        Text("Death: 5/5")
                      ])
                ])),
            const SizedBox(height: 40),
            SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.navyDeep),
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LeaveApplicationPage())),
                    child: const Text("Apply Leaves",
                        style: TextStyle(color: Colors.white, fontSize: 16)))),
            
            const SizedBox(height: 30),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text("My Applications",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 10),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('leave_requests')
                  .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
                  // Note: Requires Index if we use orderBy here alongside where. 
                  // For now, sorting client-side or relying on natural order.
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Text("No leave applications found.", style: TextStyle(color: Colors.grey));
                }

                final docs = snapshot.data!.docs;
                // Sort by appliedAt descending (newest first)
                docs.sort((a, b) {
                  final tA = a['appliedAt'] as Timestamp?;
                  final tB = b['appliedAt'] as Timestamp?;
                  if (tA == null) return -1;
                  if (tB == null) return 1;
                  return tB.compareTo(tA);
                });

                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    final type = data['leaveType'] ?? 'Leave';
                    final status = data['status'] ?? 'Pending';
                    final start = data['startDate'] ?? '';
                    final end = data['endDate'] ?? '';
                    
                    Color statusColor = Colors.orange;
                    if (status == 'Approved') statusColor = Colors.green;
                    if (status == 'Rejected') statusColor = Colors.red;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade200),
                        boxShadow: [BoxShadow(color: Colors.grey.shade100, blurRadius: 4)]
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(type, style: const TextStyle(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text("$start - $end", style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: statusColor)
                            ),
                            child: Text(
                              status, 
                              style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12)
                            ),
                          )
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ApplyLeaveListPage extends StatelessWidget {
  const ApplyLeaveListPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: AppColors.royalBlue,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context)),
          title: const Text("Apply Leave",
              style: TextStyle(color: Colors.white))),
      body: ListView(padding: const EdgeInsets.all(20), children: const [
        ListTile(title: Text("Annual Leave"), trailing: Icon(Icons.add)),
        ListTile(title: Text("Medical Leave"), trailing: Icon(Icons.add))
      ]),
    );
  }
}
