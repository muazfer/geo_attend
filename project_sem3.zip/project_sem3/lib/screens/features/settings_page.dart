import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: AppColors.royalBlue,
            title:
            const Text("Settings", style: TextStyle(color: Colors.white))),
        body: const Center(child: Text("Settings Content")));
  }
}
