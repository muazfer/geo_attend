import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';

class PaymentSalaryDashboard extends StatelessWidget {
  const PaymentSalaryDashboard({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: AppColors.royalBlue,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context)),
          title: const Text("Payment", style: TextStyle(color: Colors.white))),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("RM 1,500",
                style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: AppColors.navyDeep)),
            const Text("Salary Paid", style: TextStyle(color: Colors.green)),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SalaryDetailsPage())),
                child: const Text("View Details")),
          ],
        ),
      ),
    );
  }
}

class SalaryDetailsPage extends StatelessWidget {
  const SalaryDetailsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: AppColors.royalBlue,
          title: const Text("Details", style: TextStyle(color: Colors.white))),
      body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const ListTile(title: Text("Basic Salary"), trailing: Text("RM 1200")),
            const ListTile(title: Text("Overtime"), trailing: Text("RM 300")),
            const Divider(),
            const ListTile(
                title: Text("Total"),
                trailing: Text("RM 1500",
                    style: TextStyle(fontWeight: FontWeight.bold))),
            const Spacer(),
            ElevatedButton(
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ExportPdfPage())),
                child: const Text("Download PDF"))
          ])),
    );
  }
}

class ExportPdfPage extends StatelessWidget {
  const ExportPdfPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black54,
        body: Center(
            child: Container(
                padding: const EdgeInsets.all(20),
                color: Colors.white,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text("PDF Exported"),
                  ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Close"))
                ]))));
  }
}
