import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import '../../widgets/clock_out_template.dart';
import 'clock_out_screen5.dart';

class ClockOutScreen4 extends StatefulWidget {
  final File? imageFile;
  const ClockOutScreen4({super.key, this.imageFile});

  @override
  State<ClockOutScreen4> createState() => _ClockOutScreen4State();
}

class _ClockOutScreen4State extends State<ClockOutScreen4> {
  bool _isSubmitting = false;

  Future<void> _submitClockOut() async {
    setState(() => _isSubmitting = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        String? base64Image;
        if (widget.imageFile != null) {
          final bytes = await widget.imageFile!.readAsBytes();
          base64Image = base64Encode(bytes);
        }

        await FirebaseFirestore.instance.collection('attendance').add({
          'userId': user.uid,
          'type': 'Clock Out',
          'timestamp': FieldValue.serverTimestamp(),
          'location': 'Kolej kediaman A11', // Generic for now
          'imagePath': base64Image ?? '', 
          'dateStr': DateFormat('yyyy-MM-dd').format(DateTime.now()),
          'timeStr': DateFormat('HH:mm a').format(DateTime.now()),
          'email': user.email ?? 'No Email',
          'userName': user.displayName ?? 'Unknown User',
        });
      }
      if (mounted) {
        final clockOutTime = DateFormat('hh:mm a').format(DateTime.now());
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ClockOutScreen5(clockOutTime: clockOutTime)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final timeStr = DateFormat('hh: mm a').format(now);

    return _isSubmitting 
    ? const Scaffold(body: Center(child: CircularProgressIndicator()))
    : ClockOutTemplate(
      btnText: "Clock Out",
      btnColor: AppColors.salmonRed,
      placeholderText: "",
      placeStatus: "Kolej kediaman A11",
      faceStatus: "Recognise",
      hasPhoto: true,
      localImage: widget.imageFile,
      timeText: timeStr,
      onBtnPressed: _submitClockOut,
      onCameraTap: () {},
    );
  }
}
