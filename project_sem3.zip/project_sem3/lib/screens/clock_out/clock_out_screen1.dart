import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import '../../widgets/clock_out_template.dart';
import 'clock_out_gps_page.dart';
import 'clock_out_screen4.dart';

class ClockOutScreen1 extends StatefulWidget {
  const ClockOutScreen1({super.key});

  @override
  State<ClockOutScreen1> createState() => _ClockOutScreen1State();
}

class _ClockOutScreen1State extends State<ClockOutScreen1> {
  File? _imageFile;

  @override
  Widget build(BuildContext context) {
    return ClockOutTemplate(
      btnText: "GPS DETECTION",
      btnColor: AppColors.skyBlue,
      placeholderText: "Press here to take picture place",
      placeStatus: "Kolej kediaman A11",
      faceStatus: "Recognise",
      hasPhoto: _imageFile != null,
      localImage: _imageFile,
      onBtnPressed: () {
        // GPS DETECTION Button -> Opens GPS Page
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ClockOutGPSPage(imageFile: _imageFile)));
      },
      onCameraTap: () async {
        final ImagePicker picker = ImagePicker();
        final XFile? image = await picker.pickImage(
          source: ImageSource.camera,
          imageQuality: 50,
          maxWidth: 600,
        );
        if (image != null) {
           setState(() {
             _imageFile = File(image.path);
           });
        }
      },
    );
  }
}
