import 'package:flutter/material.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import 'clock_out_screen2.dart';

class ClockOutGPSPage extends StatelessWidget {
  final File? imageFile;
  const ClockOutGPSPage({super.key, this.imageFile});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GPS", style: TextStyle(color: Colors.white)),
        backgroundColor: AppColors.royalBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [Color(0xFF4FC3F7), Color(0xFF2B55CC)]),
            ),
            child: const Row(
              children: [
                Icon(Icons.location_on, size: 40, color: Colors.white),
                SizedBox(width: 10),
                Expanded(
                    child: Text("Work people inside this Space",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold))),
              ],
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Container(color: Colors.grey[200]),
                const Center(
                    child: Opacity(
                        opacity: 0.2,
                        child:
                        Icon(Icons.map, size: 300, color: Colors.grey))),
                Positioned(
                  top: 20,
                  left: 20,
                  right: 20,
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(25),
                        boxShadow: [
                          const BoxShadow(color: Colors.black12, blurRadius: 5)
                        ]),
                    child: const TextField(
                      decoration: InputDecoration(
                          hintText: "Search location...",
                          prefixIcon: Icon(Icons.search, color: Colors.grey),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(top: 15)),
                    ),
                  ),
                ),
                Center(
                  child: GestureDetector(
                    onTap: () {
                      // RED CIRCLE Button -> Opens Clock Out 2
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ClockOutScreen2(imageFile: imageFile)));
                    },
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                          color: AppColors.alertRed.withOpacity(0.3),
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppColors.alertRed, width: 2)),
                      child: const Center(
                          child: Icon(Icons.location_on,
                              color: AppColors.alertRed, size: 40)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
            child: const Column(
              children: [
                ListTile(
                    leading: Icon(Icons.my_location, color: Colors.blue),
                    title: Text("Use my current location",
                        style: TextStyle(fontWeight: FontWeight.bold))),
                Divider(),
                ListTile(
                    leading: Icon(Icons.location_on, color: Colors.grey),
                    title: Text("123, Jalan Universiti...",
                        style: TextStyle(color: Colors.grey))),
              ],
            ),
          )
        ],
      ),
    );
  }
}
