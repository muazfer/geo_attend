import 'package:flutter/material.dart';
import 'dart:io';
import '../../utils/app_colors.dart';
import '../../widgets/clock_out_template.dart';
import '../../widgets/clock_out_alert_popup.dart';
import 'clock_out_screen4.dart';

class ClockOutScreen2 extends StatelessWidget {
  final File? imageFile;
  const ClockOutScreen2({super.key, this.imageFile});
  @override
  Widget build(BuildContext context) {
    return ClockOutTemplate(
      btnText: "Next",
      btnColor: AppColors.skyBlue,
      placeholderText: "Press here to take picture place",
      placeStatus: "Kolej kediaman A11",
      faceStatus: "Recognise",
      hasPhoto: imageFile != null,
      localImage: imageFile,
      onBtnPressed: () {
        if (imageFile != null) {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ClockOutScreen4(imageFile: imageFile)));
        } else {
          showDialog(
              context: context, builder: (_) => const ClockOutAlertPopup());
        }
      },
      onCameraTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (context) => ClockOutScreen4(imageFile: imageFile))),
    );
  }
}
