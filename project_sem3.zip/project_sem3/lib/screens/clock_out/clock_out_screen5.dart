import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';

class ClockOutScreen5 extends StatelessWidget {
  final String clockOutTime;
  const ClockOutScreen5({super.key, required this.clockOutTime});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Clock Out",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: AppColors.royalBlue,
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          const SizedBox(height: 40),
          const Text("Have a nice day",
              style: TextStyle(
                  fontFamily: 'Cursive',
                  fontSize: 32,
                  fontWeight: FontWeight.bold)),
          const Icon(Icons.flutter_dash,
              color: Colors.pinkAccent, size: 40),
          const Spacer(),
          Container(
            width: 300,
            height: 80,
            decoration: BoxDecoration(
              color: AppColors.salmonRed,
              borderRadius: BorderRadius.circular(40),
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 10,
                    offset: const Offset(0, 5))
              ],
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40)),
              ),
              onPressed: () {
                // BUTTON -> Returns to Home Page
                Navigator.popUntil(context, (route) => route.isFirst);
              },
              child: Text("Clock Out $clockOutTime",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          const Spacer(),
          Container(
            height: 150,
            width: double.infinity,
            color: Colors.grey[100],
            child: const Icon(Icons.assignment_turned_in,
                size: 100, color: Colors.teal),
          )
        ],
      ),
    );
  }
}
