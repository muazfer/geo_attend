import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import 'login_page.dart';

class MainSelectionPage extends StatelessWidget {
  const MainSelectionPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF5356FF),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 120,
                width: 120,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: const Icon(Icons.school,
                    size: 60, color: Color(0xFF5356FF)),
              ),
              const SizedBox(height: 30),
              const Text(
                "MyCleanAttend\nUTHM",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1.5),
              ),

              const SizedBox(height: 20),
              _buildSelectionButton(context, "Cleaner"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSelectionButton(BuildContext context, String title) {
    return SizedBox(
      width: 250,
      height: 55,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.navyDeep,
          foregroundColor: Colors.white,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (context) => const LoginPage())),
        child: Text(title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
