import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import '../../utils/app_colors.dart';

class MyRecordPage extends StatelessWidget {
  const MyRecordPage({super.key});

  @override
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Scaffold(body: Center(child: Text("Please login to view records")));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Records'),
        backgroundColor: AppColors.royalBlue,
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('attendance')
            .where('userId', isEqualTo: user.uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
             return Center(child: Text("Error: ${snapshot.error}"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No records found"));
          }

          final docs = snapshot.data!.docs;
          
          // 1. Sort by timestamp ascending to process chronology
          docs.sort((a, b) {
            final aData = a.data() as Map<String, dynamic>;
            final bData = b.data() as Map<String, dynamic>;
            final tA = aData['timestamp'] as Timestamp?;
            final tB = bData['timestamp'] as Timestamp?;
            if (tA == null) return -1;
            if (tB == null) return 1;
            return tA.compareTo(tB);
          });

          // 2. Group into sessions
          List<AttendanceSession> sessions = [];
          Map<String, dynamic>? currentClockIn;
          
          for (var doc in docs) {
            final data = doc.data() as Map<String, dynamic>;
            final type = data['type'];
            
            if (type == 'Clock In') {
              // If we already had a pending Clock In, push it as incomplete
              if (currentClockIn != null) {
                sessions.add(AttendanceSession(clockIn: currentClockIn, clockOut: null));
              }
              currentClockIn = data;
            } else if (type == 'Clock Out') {
              if (currentClockIn != null) {
                // Pair found
                sessions.add(AttendanceSession(clockIn: currentClockIn, clockOut: data));
                currentClockIn = null;
              } else {
                // Orphaned clock out (missed clock in?)
                sessions.add(AttendanceSession(clockIn: null, clockOut: data));
              }
            }
          }
          // Handle trailing pending clock in
          if (currentClockIn != null) {
             sessions.add(AttendanceSession(clockIn: currentClockIn, clockOut: null));
          }

          // 3. Sort sessions descending (newest first)
          sessions.sort((a, b) {
             final tA = a.startTime;
             final tB = b.startTime;
             if (tA == null) return 1;
             if (tB == null) return -1;
             return tB.compareTo(tA);
          });

          return ListView.builder(
            itemCount: sessions.length,
            padding: const EdgeInsets.all(12),
            itemBuilder: (context, index) {
              return _buildSessionCard(sessions[index]);
            },
          );
        },
      ),
    );
  }

  Widget _buildSessionCard(AttendanceSession session) {
    // Helper to decode image
    ImageProvider? getImage(String? path) {
      if (path == null || path.isEmpty) return null;
      if (path.length > 200) {
        try {
          return MemoryImage(base64Decode(path));
        } catch (e) {
          return null;
        }
      }
      return FileImage(File(path));
    }

    final dateStr = session.clockIn?['dateStr'] ?? session.clockOut?['dateStr'] ?? 'Unknown Date';
    final inTime = session.clockIn?['timeStr'] ?? '--:--';
    final outTime = session.clockOut?['timeStr'] ?? '--:--';
    
    final inImage = getImage(session.clockIn?['imagePath']);
    final outImage = getImage(session.clockOut?['imagePath']);

    return Card(
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 8),
                Text(
                  dateStr,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: session.isComplete ? Colors.green[50] : Colors.orange[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: session.isComplete ? Colors.green : Colors.orange),
                  ),
                  child: Text(
                    session.isComplete ? "Completed" : "Incomplete",
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: session.isComplete ? Colors.green : Colors.deepOrange,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            
            // Clock In Row
            Row(
              children: [
                _buildTimeColumn("Clock In", inTime, Colors.green),
                const Spacer(),
                _buildThumbnail(inImage),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Clock Out Row
            Row(
              children: [
                _buildTimeColumn("Clock Out", outTime, Colors.red),
                const Spacer(),
                _buildThumbnail(outImage),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeColumn(String label, String time, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              label == "Clock In" ? Icons.login : Icons.logout,
              size: 20,
              color: color,
            ),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w500)),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28),
          child: Text(
            time,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  Widget _buildThumbnail(ImageProvider? image) {
    if (image == null) {
      return Container(
        width: 60, height: 60,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
        ),
        child: const Icon(Icons.image_not_supported, color: Colors.grey),
      );
    }
    return Container(
      width: 60, height: 60,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade300),
        image: DecorationImage(image: image, fit: BoxFit.cover),
      ),
    );
  }
}

class AttendanceSession {
  final Map<String, dynamic>? clockIn;
  final Map<String, dynamic>? clockOut;

  AttendanceSession({this.clockIn, this.clockOut});

  bool get isComplete => clockIn != null && clockOut != null;
  
  DateTime? get startTime {
    if (clockIn != null) return (clockIn!['timestamp'] as Timestamp).toDate();
    if (clockOut != null) return (clockOut!['timestamp'] as Timestamp).toDate();
    return null;
  }
}
