import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../utils/app_colors.dart';
import 'auth/login_page.dart';
import 'auth/main_selection_page.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Column(children: [
        Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 60, bottom: 20),
            decoration: const BoxDecoration(
                color: AppColors.royalBlue,
                borderRadius:
                BorderRadius.vertical(bottom: Radius.circular(30))),
            child: const Column(children: [
              CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 50)),
              Text("Ikmal",
                  style: TextStyle(color: Colors.white, fontSize: 20))
            ])),
        const ListTile(title: Text("Personal Details")),
        const ListTile(title: Text("Contact Details")),
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const MainSelectionPage()),
                        (r) => false);
              }
            },
            child: const Text("Log Out", style: TextStyle(color: Colors.white)))
      ]),
    );
  }
}
