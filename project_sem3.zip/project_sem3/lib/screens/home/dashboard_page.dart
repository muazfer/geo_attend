import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import '../features/settings_page.dart';
import '../features/leave_page.dart';
import '../features/calendar_page.dart';
import '../features/payment_page.dart';
import '../features/overtime_page.dart';
import '../features/message_list_page.dart';
import '../clock_in/clock_in_camera_step1.dart';
import '../clock_in/clock_in_camera_error_page.dart';
import '../clock_out/clock_out_screen1.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.only(
                  top: 50, left: 20, right: 20, bottom: 30),
              decoration: const BoxDecoration(
                color: Color(0xFF5356FF),
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("MyCleanAttend UTHM",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      GestureDetector(
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SettingsPage())),
                        child: const Icon(Icons.settings, color: Colors.white),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text("Good Morning!",
                      style: TextStyle(color: Colors.white70)),
                  const Text("Ikmal Bin Sarafuddin",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),

                  // CLOCK IN / LOG SECTION
                  Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        // Clock In Button (Standard Flow)
                        GestureDetector(
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                  const ClockInCameraStep1())),
                          child: CircleAvatar(
                              radius: 30,
                              backgroundColor: Colors.green[100],
                              child: const Text("CLOCK IN",
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold))),
                        ),

                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                                color: Colors.green[50],
                                borderRadius: BorderRadius.circular(10)),
                            child: const Text("Default Shift",
                                style: TextStyle(color: Colors.green))),

                        // LOG Button (Triggers the Error/Camera Fail Flow - Image 8)
                        GestureDetector(
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                  const ClockInCameraErrorPage())),
                          child: Container(
                              height: 60,
                              width: 80,
                              decoration: BoxDecoration(
                                  color: Colors.teal,
                                  borderRadius: BorderRadius.circular(10)),
                              child: const Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.login, color: Colors.white),
                                    Text("Log",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 12))
                                  ])),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                children: [
                  _buildMenuButton(
                      context, "Leave", Icons.calendar_today, Colors.blue,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const LeavePage()))),
                  // CLOCK OUT BUTTON (Triggers the new Clock Out Flow - Image 2)
                  _buildMenuButton(context, "Clock Out", Icons.access_time,
                      Colors.red[300]!,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ClockOutScreen1()))),

                  // Calendar Button (Triggers Calendar Page)
                  _buildMenuButton(
                      context, "Calendar", Icons.grid_view, Colors.black87,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const CalendarPage()))),

                  // Payment Button
                  _buildMenuButton(
                      context, "Payment", Icons.credit_card, Colors.blue[900]!,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                              const PaymentSalaryDashboard()))),
                  _buildMenuButton(context, "Overtime", Icons.work, Colors.lightBlue,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const OvertimePage()))),
                  _buildMenuButton(
                      context, "Message", Icons.message, Colors.blue[300]!,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const MessageListPage()))),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text("News And Highlights",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const SizedBox(height: 10),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              height: 120,
              decoration: BoxDecoration(
                  color: Colors.black, borderRadius: BorderRadius.circular(15)),
              child: const Center(
                  child: Text("ATTENDANCE",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold))),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuButton(
      BuildContext context, String label, IconData icon, Color color,
      {required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 5,
                spreadRadius: 2)
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 30),
            const SizedBox(height: 8),
            Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: Colors.teal)),
          ],
        ),
      ),
    );
  }
}
